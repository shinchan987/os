#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>

sem_t agent_sem;
sem_t tobacco_sem,paper_sem,matches_sem;

void* agent_thread(void* arg){
    while(1){
        sem_wait(&agent_sem);

        //genearte random ingredients
        int ingredients=rand()%3;

        if(ingredients==0){
            printf("Agent places tobacco and paper on table\n");
            sem_post(&matches_sem);
        }
        else if(ingredients==1){
            printf("agent places tobacco and matches on table\n");
            sem_post(&paper_sem);
        }
        else{
            printf("Agent places paper and matches on table\n");
            sem_post(&tobacco_sem);
        }
        printf("\n");
    }
}



void *smoker_thread(void* arg){
    sem_t *ingredient_sem = (sem_t *)arg;

    while(1){
        sem_wait(ingredient_sem);

        printf("Smoker with ingreident %d has picked up ingredient\n",*(int *)arg);

        printf("Smoker with ingreident %d is rolling and smoking a cigarrte \n",*(int *)arg);


        sleep(1);
        sem_post(&agent_sem);
        printf("\n");

    }
}



int main(){
    pthread_t agent_tid,smoker_tid[3];
    sem_init(&agent_sem,0,1);
    sem_init(&tobacco_sem,0,0);
    sem_init(&paper_sem,0,0);
    sem_init(&matches_sem,0,0);


    int tobacco=1;
    int paper=2;
    int matches=3;

    pthread_create(&agent_tid,NULL,agent_thread,NULL);
    pthread_create(&smoker_tid[0],NULL,smoker_thread,&tobacco);
    pthread_create(&smoker_tid[1],NULL,smoker_thread,&paper);
    pthread_create(&smoker_tid[2],NULL,smoker_thread,&matches);


    pthread_join(agent_tid,NULL);
    pthread_join(smoker_tid[0],NULL);
    pthread_join(smoker_tid[1],NULL);
    pthread_join(smoker_tid[2],NULL);


    sem_destroy(&agent_sem);
    sem_destroy(&tobacco_sem);
    sem_destroy(&matches_sem);
    sem_destroy(&paper_sem);

    return 0;
}
