#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define num_philosphers 5

typedef struct
{
    pthread_mutex_t mutex;
    pthread_cond_t cond[num_philosphers];
    int isEating[num_philosphers];
} Monitor;

Monitor monitor;

void initMonitor(Monitor *mon)
{
    pthread_mutex_init(&mon->mutex, NULL);
    for (int i = 0; i < num_philosphers; i++)
    {
        pthread_cond_init(&mon->cond[i], NULL);
        mon->isEating[i] = 0;
    }
}

void pickup_fork(int philospher_id)
{
    pthread_mutex_lock(&monitor.mutex);
    monitor.isEating[philospher_id] = 1;

    while (monitor.isEating[(philospher_id + 1) % num_philosphers] || monitor.isEating[(philospher_id + num_philosphers - 1) % num_philosphers])
    {
        pthread_cond_wait(&monitor.cond[philospher_id], &monitor.mutex);
    }
    pthread_mutex_unlock(&monitor.mutex);
}

void return_fork(int philospher_id)
{
    pthread_mutex_lock(&monitor.mutex);
    monitor.isEating[philospher_id] = 0;
    pthread_cond_signal(&monitor.cond[(philospher_id + 1) % num_philosphers]);
    pthread_cond_signal(&monitor.cond[(philospher_id + num_philosphers - 1) % num_philosphers]);

    pthread_mutex_unlock(&monitor.mutex);
}

void *philospher(void *args)
{
    int philospher_id = *(int *)args;
    while (1)
    {
        printf("Philospher %d is thinking\n", philospher_id);
        printf("Philospher %d is hungry\n", philospher_id);

        printf("Philospher %d is eating\n", philospher_id);
        sleep(rand() % 3 + 1);

        printf("Philospher %d finished eating\n", philospher_id);

        return_fork(philospher_id);
    }
}

int main()
{
    pthread_t philosphers[num_philosphers];
    int philospher_ids[num_philosphers];

    initMonitor(&monitor);

    for (int i = 0; i < num_philosphers; i++)
    {
        philospher_ids[i] = i;
        pthread_create(&philosphers[i], NULL, philospher, &philospher_ids[i]);
    }
    for (int i = 0; i < num_philosphers; i++)
    {
        pthread_join(philosphers[i], NULL);
    }
    return 0;
}
