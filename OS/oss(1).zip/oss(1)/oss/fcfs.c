#include <stdio.h>
#include <stdlib.h>
void fcfs(int n, int *bT, int *cT)
{
    int i, t = 0;
    for (i = 0; i < n; i++)
    {
        t += bT[i];
        cT[i] = t;
    }
}
void calculate(int n, int *bT, int *aT, int *cT, int *wT, int *tat)
{
    int i;
    for (i = 0; i < n; i++)
    {
        tat[i] = cT[i] - aT[i];
        wT[i] = tat[i] - bT[i];
    }
}
int main()
{
    int burstTime[] = {24, 3, 3, 7};
    int arrivalTime[4] = {0, 0, 0, 0};
    int completionTime[4] = {0};
    int waitingTime[4],
        turnaroundTime[4];
    fcfs(4, burstTime, completionTime);
    calculate(4, burstTime, arrivalTime, completionTime, waitingTime, turnaroundTime);
    printf("First Come First Serve:\nProcess\tTAT\tWT\n");
    int i;
    for (i = 0; i < 4; i++)
    {
        printf("P%d\t%d\t%d\n", i, turnaroundTime[i], waitingTime[i]);
    }
}
