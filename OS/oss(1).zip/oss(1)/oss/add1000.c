#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>

#define ITERATIONS 5

// Define the structure of shared memory
struct SharedMemory {
    int sharedVariable;
    sem_t semaphore;
};

void child_process(struct SharedMemory *sharedMemory, int increment, int sleep_duration) {
    for (int i = 0; i < ITERATIONS; ++i) {
        sem_wait(&sharedMemory->semaphore);

        // Critical section
        int temp = sharedMemory->sharedVariable;
        usleep(sleep_duration);  // Simulate a race condition
        temp += increment;
        sharedMemory->sharedVariable = temp;

        sem_post(&sharedMemory->semaphore);

        // Sleep for a random amount of time
        usleep(rand() % 1000000);
    }
}

int main() {
    // Create shared memory
    key_t key = ftok("/tmp", 'S');
    int shmid = shmget(key, sizeof(struct SharedMemory), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach shared memory
    struct SharedMemory *sharedMemory = shmat(shmid, NULL, 0);
    if (*(int*)sharedMemory == -1) {
        perror("shmat");
        exit(1);
    }

    // Initialize shared memory
    sharedMemory->sharedVariable = 1000;
    sem_init(&sharedMemory->semaphore, 1, 1);

    // Create parent process
    pid_t parent_pid = getpid();
    printf("Parent process ID: %d\n", parent_pid);

    // Create child processes
    pid_t pid_a = fork();
    if (pid_a == 0) {
        // Child A process
        child_process(sharedMemory, 200, 50000);  // Increase sleep duration for process A
        exit(0);
    } else if (pid_a < 0) {
        perror("Error creating child process A");
        exit(1);
    }

    pid_t pid_b = fork();
    if (pid_b == 0) {
        // Child B process
        child_process(sharedMemory, 100, 0);  // No sleep for process B
        exit(0);
    } else if (pid_b < 0) {
        perror("Error creating child process B");
        exit(1);
    }

    // Wait for child processes to finish
    waitpid(pid_a, NULL, 0);
    waitpid(pid_b, NULL, 0);

    // Destroy semaphore
    sem_destroy(&sharedMemory->semaphore);

    // Detach and remove shared memory
    shmdt(sharedMemory);
    shmctl(shmid, IPC_RMID, NULL);

    printf("Parent process exiting.\n");

    return 0;
}

