#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define MAX_ROWS 100  // Maximum number of rows in the matrices
#define MAX_COLS 100  // Maximum number of columns in the matrices
#define NUM_THREADS 4 // Number of threads
int matrixA[MAX_ROWS][MAX_COLS];
int matrixB[MAX_ROWS][MAX_COLS];
int resultAddition[MAX_ROWS][MAX_COLS];
int resultSubtraction[MAX_ROWS][MAX_COLS];
int numRows, numCols;
// Structure to hold thread arguments
struct ThreadArgs
{
    int startRow;
    int endRow;
};
// Function to perform addition of matrix elements within the given rows
void *performAddition(void *args)
{
    struct ThreadArgs *threadArgs = (struct ThreadArgs *)args;
    int startRow = threadArgs->startRow;
    int endRow = threadArgs->endRow;
    for (int i = startRow; i < endRow; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            resultAddition[i][j] = matrixA[i][j] + matrixB[i][j];
        }
    }
    pthread_exit(NULL);
}
// Function to perform subtraction of matrix elements within the given rows
void *performSubtraction(void *args)
{
    struct ThreadArgs *threadArgs = (struct ThreadArgs *)args;
    int startRow = threadArgs->startRow;
    int endRow = threadArgs->endRow;
    for (int i = startRow; i < endRow; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            resultSubtraction[i][j] = matrixA[i][j] - matrixB[i][j];
        }
    }
    pthread_exit(NULL);
}
int main()
{
    pthread_t additionThreads[NUM_THREADS];
    pthread_t subtractionThreads[NUM_THREADS];
    struct ThreadArgs threadArgs[NUM_THREADS];
    // Input the number of rows and columns
    printf("Enter the number of rows: ");
    scanf("%d", &numRows);
    printf("Enter the number of columns: ");
    scanf("%d", &numCols);
    if (numRows <= 0 || numCols <= 0 || numRows > MAX_ROWS || numCols > MAX_COLS)
    {
        printf("Invalid input. Please enter valid dimensions.\n");
        return 1;
    }
    // Input matrix A
    printf("Enter elements for matrix A (%d x %d):\n", numRows, numCols);
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            scanf("%d", &matrixA[i][j]);
        }
    }
    // Input matrix B
    printf("Enter elements for matrix B (%d x %d):\n", numRows, numCols);
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            scanf("%d", &matrixB[i][j]);
        }
    }
    // Create threads for addition
    for (int i = 0; i < NUM_THREADS; i++)
    {
        threadArgs[i].startRow = i * (numRows / NUM_THREADS);
        threadArgs[i].endRow = (i == NUM_THREADS - 1) ? numRows : (i + 1) * (numRows / NUM_THREADS);
        pthread_create(&additionThreads[i], NULL, performAddition, &threadArgs[i]);
    }
    // Create threads for subtraction
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&subtractionThreads[i], NULL, performSubtraction, &threadArgs[i]);
    }
    // Wait for addition threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(additionThreads[i], NULL);
    }
    // Wait for subtraction threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(subtractionThreads[i], NULL);
    }
    // Display the result of addition
    printf("Result of addition:\n");
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            printf("%d ", resultAddition[i][j]);
        }
        printf("\n");
    } // Display the result of subtraction
    printf("Result of subtraction:\n");
    for (int i = 0; i < numRows; i++)
    {
        for (int j = 0; j < numCols; j++)
        {
            printf("%d ", resultSubtraction[i][j]);
        }
        printf("\n");
    }
    return 0;
}