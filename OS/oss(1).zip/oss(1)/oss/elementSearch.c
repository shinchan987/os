#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define MAX_ARRAY_SIZE 1000
// Maximum size of the array
#define NUM_THREADS 4
// Number of threads
int array[MAX_ARRAY_SIZE];
int arraySize;
int targetElement;
int found = 0;
// 0 indicates the element is not found
void *searchElement(void *thread_id)
{
    int tid = *((int *)thread_id);
    int start = tid * (arraySize / NUM_THREADS);
    int end = (tid == NUM_THREADS - 1) ? arraySize : (tid + 1) * (arraySize / NUM_THREADS);
    for (int i = start; i < end; i++)
    {
        if (array[i] == targetElement)
        {
            found = 1;
            // Element found
            pthread_exit(NULL);
        }
    }
    pthread_exit(NULL);
}
int main()
{
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];
    // Input array size
    printf("Enter the size of the array (up to %d): ", MAX_ARRAY_SIZE);
    scanf("%d", &arraySize);
    if (arraySize > MAX_ARRAY_SIZE || arraySize <= 0)
    {
        printf("Invalid array size. Please enter a valid size.\n");
        return 1;
    }
    // Input array elements
    printf("Enter %d elements of the array:\n", arraySize);
    for (int i = 0; i < arraySize; i++)
    {
        scanf("%d", &array[i]);
    }
    // Input the target element to search for
    printf("Enter the element to search for: ");
    scanf("%d", &targetElement);
    // Create threads
    for (int i = 0; i < NUM_THREADS; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, searchElement, &thread_ids[i]);
    }
    // Wait for threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    // Check if the element was found
    if (found)
    {
        printf("Element %d was found in the array.\n", targetElement);
    }
    else
    {
        printf("Element %d was not found in the array.\n", targetElement);
    }
    return 0;
}