#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>

#define chairs 5

sem_t customers;
sem_t barber;
sem_t mutex;

int waiting =0;

void *barber_thread(void *args){
    while(1){
        sem_wait(&customers);
        sem_wait(&mutex);

        waiting--;

        printf("Barber is cutting hair. waiting  customers: %d\n", waiting);

        sem_post(&mutex);
        sem_post(&barber);

        sleep(1);
    }

    pthread_exit(NULL);
}


void *customers_thread(void *args){
    sem_wait(&mutex);

    if(waiting< chairs){
        waiting++;
        printf("customer arrived. waiting customers: %d\n", waiting);

        sem_post(&mutex);
        sem_post(&customers);
        sem_post(&barber);

        printf("customer getting haircut\n");

    }
    else{
        sem_post(&mutex);
        printf("no free chairs.customers leaves \n");
    }

    pthread_exit(NULL);
}


int main(){
    pthread_t barber_tid,customer_tid;
    sem_init(&customers,0,0);
    sem_init(&barber,0,0);
    sem_init(&mutex,0,1);

    pthread_create(&barber_tid,NULL,barber_thread,NULL);

    for(int i = 0; i <5;i++){
        pthread_create(&customer_tid,NULL,customers_thread,NULL);
        sleep(1);
    }

    pthread_join(barber_tid,NULL);
}