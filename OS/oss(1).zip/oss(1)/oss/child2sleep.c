#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/stat.h>


int main(){
    pid_t pid1;
    pid_t pid2;

    pid1 = fork();
    if(pid1<0){
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if(pid1==0){
        pid2=fork();
        if(pid2<0){
            perror("fork");
            exit(EXIT_FAILURE);
        }
        for(int i=0; i<5; i++){
            printf("iteration %d of cpid= %d...\n", i+1, getpid());
           // sleep(1);
        }
    }
    else{
        wait(NULL);
        printf("parent is executing \n");
    }
}
