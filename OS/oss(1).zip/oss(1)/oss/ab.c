#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>

sem_t semaphore;

int sharedData=0;

void *processA(void *arg){
    for(int i=0;i<5;i++){
        sem_wait(&semaphore);

       
        printf("processA: ideration  %d\n",i);

        sem_post(&semaphore);

        usleep(rand()%500000);
    }
    pthread_exit(NULL);
}

void *processB(void *arg){
    for(int i=0;i<5;i++){
        sem_wait(&semaphore);

         sharedData=i;
        printf("processB: ideration  %d\n",sharedData);
        sem_post(&semaphore);

        usleep(rand()%500000);
    }
    pthread_exit(NULL);
}


int main(){
    if(sem_init(&semaphore,0,1)!=0){
        perror("semaphore initialisation failed");
        exit(EXIT_FAILURE);
    }

    pthread_t threadA,threadB;

    if(pthread_create(&threadA,NULL,processA,NULL)!=0 || pthread_create(&threadB,NULL,processB,NULL)!=0){
        perror("thread creation failsed");
        exit(EXIT_FAILURE);
    }


    pthread_join(threadA,NULL);
    pthread_join(threadB,NULL);

    sem_destroy(&semaphore);
}