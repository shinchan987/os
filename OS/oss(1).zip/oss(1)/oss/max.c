#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <limits.h>
#define MAX_ARRAY_SIZE 1000 // Maximum size of the array
#define NUM_THREADS 4       // Number of threads
int array[MAX_ARRAY_SIZE];
int arraySize;
int max = INT_MIN;
// Initialize max with the smallest possible integer value
void *findMax(void *thread_id)
{
    int tid = *((int *)thread_id);
    int start = tid * (arraySize / NUM_THREADS);
    int end = (tid == NUM_THREADS - 1) ? arraySize : (tid + 1) * (arraySize / NUM_THREADS);
    for (int i = start; i < end; i++)
    {
        if (array[i] > max)
        {
            max = array[i];
        }
    }
    pthread_exit(NULL);
}
int main()
{
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];
    // Input array size
    printf("Enter the size of the array (up to %d): ", MAX_ARRAY_SIZE);
    scanf("%d", &arraySize);
    if (arraySize > MAX_ARRAY_SIZE || arraySize <= 0)
    {
        printf("Invalid array size. Please enter a valid size.\n");
        return 1;
    }
    // Input array elements
    printf("Enter %d elements of the array:\n", arraySize);
    for (int i = 0; i < arraySize; i++)
    {
        scanf("%d", &array[i]);
    } // Create threads
    for (int i = 0; i < NUM_THREADS; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, findMax, &thread_ids[i]);
    }
    // Wait for threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    } // Display the maximum element
    printf("Maximum element in the array: %d\n", max);
    return 0;
}
