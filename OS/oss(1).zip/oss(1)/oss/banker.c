#include <stdio.h>
#include <pthread.h>

#define NUMBER_OF_CUSTOMERS 5
#define NUMBER_OF_RESOURCES 3

int available[NUMBER_OF_RESOURCES];
int maximum[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];
int allocation[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];
int need[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];

pthread_mutex_t mutex;

int is_safe() {
    int work[NUMBER_OF_RESOURCES];
    int finish[NUMBER_OF_CUSTOMERS] = {0};

    // Initialize work and finish arrays
    for (int i = 0; i < NUMBER_OF_RESOURCES; i++)
        work[i] = available[i];

    int count = 0;
    while (count < NUMBER_OF_CUSTOMERS) {
        int found = 0;
        for (int i = 0; i < NUMBER_OF_CUSTOMERS; i++) {
            if (!finish[i]) {
                int j;
                for (j = 0; j < NUMBER_OF_RESOURCES; j++) {
                    if (need[i][j] > work[j])
                        break;
                }
                if (j == NUMBER_OF_RESOURCES) {
                    // Resources can be allocated to process i
                    for (int k = 0; k < NUMBER_OF_RESOURCES; k++)
                        work[k] += allocation[i][k];

                    finish[i] = 1;
                    count++;
                    found = 1;
                }
            }
        }
        if (!found)
            return 0; // Unsafe state
    }
    return 1; // Safe state
}

void release_resources(int customer_num, int release[]) {
    pthread_mutex_lock(&mutex);

    for (int i = 0; i < NUMBER_OF_RESOURCES; i++) {
        available[i] += release[i];
        allocation[customer_num][i] -= release[i];
        need[customer_num][i] += release[i];
    }

    pthread_mutex_unlock(&mutex);
}

int request_resources(int customer_num, int request[]) {
    pthread_mutex_lock(&mutex);

    for (int i = 0; i < NUMBER_OF_RESOURCES; i++) {
        if (request[i] > need[customer_num][i] || request[i] > available[i]) {
            pthread_mutex_unlock(&mutex);
            return 0; // Request exceeds need or available resources
        }
    }

    for (int i = 0; i < NUMBER_OF_RESOURCES; i++) {
        available[i] -= request[i];
        allocation[customer_num][i] += request[i];
        need[customer_num][i] -= request[i];
    }

    if (!is_safe()) {
        // Unsafe state, rollback the changes
        for (int i = 0; i < NUMBER_OF_RESOURCES; i++) {
            available[i] += request[i];
            allocation[customer_num][i] -= request[i];
            need[customer_num][i] += request[i];
        }
        pthread_mutex_unlock(&mutex);
        return 0;
    }

    pthread_mutex_unlock(&mutex);
    return 1; // Request granted
}

void* customer_thread(void* arg) {
    int customer_num = *(int*)arg;

    // Example request and release for each customer
    int request[NUMBER_OF_RESOURCES] = {0, 0, 0};
    int release[NUMBER_OF_RESOURCES] = {1, 1, 1};

    printf("Customer %d requesting resources...\n", customer_num);
    if (request_resources(customer_num, request))
        printf("Customer %d request granted.\n", customer_num);
    else
        printf("Customer %d request denied.\n", customer_num);

    printf("Customer %d releasing resources...\n", customer_num);
    release_resources(customer_num, release);

    return NULL;
}

int main() {
    // Initialize available, maximum, allocation, and need arrays
    int init_available[NUMBER_OF_RESOURCES] = {3, 3, 2};
    int init_maximum[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES] = {
        {7, 5, 3},
        {3, 2, 2},
        {9, 0, 2},
        {2, 2, 2},
        {4, 3, 3}
    };

    for (int i = 0; i < NUMBER_OF_RESOURCES; i++)
        available[i] = init_available[i];

    for (int i = 0; i < NUMBER_OF_CUSTOMERS; i++)
        for (int j = 0; j < NUMBER_OF_RESOURCES; j++) {
            maximum[i][j] = init_maximum[i][j];
            allocation[i][j] = 0;
            need[i][j] = maximum[i][j];
        }

    pthread_mutex_init(&mutex, NULL);

    pthread_t threads[NUMBER_OF_CUSTOMERS];
    int thread_args[NUMBER_OF_CUSTOMERS];

    for (int i = 0; i < NUMBER_OF_CUSTOMERS; i++) {
        thread_args[i] = i;
        pthread_create(&threads[i], NULL, customer_thread, &thread_args[i]);
    }

    for (int i = 0; i < NUMBER_OF_CUSTOMERS; i++)
        pthread_join(threads[i], NULL);

    pthread_mutex_destroy(&mutex);

    return 0;
}
