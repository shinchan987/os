#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int array[1000];
int partialSum[4] = {0};
#define MAX_ARRAY_SIZE 1000
#define NUM_THREADS 4
int arraySize;

void *calculateSum(void *thread_id)
{
    int tid = *((int *)thread_id);
    int start = tid * (arraySize / 4);

    int end = (tid == 3) ? arraySize : (tid + 1) * (arraySize / 4);

    for (int i = start; i < end; i++)
    {
        partialSum[tid] += array[i];
    }
    pthread_exit(NULL);
}

int main()
{
    pthread_t threads[4];
    int thread_ids[4];
    // Input array size
    printf("Enter the size of the array (up to %d): ", 1000);
    scanf("%d", &arraySize);
    if (arraySize > MAX_ARRAY_SIZE || arraySize <= 0)
    {
        printf("Invalid array size. Please enter a valid size.\n");
        return 1;
    }
    // Input array elements
    printf("Enter %d elements of the array:\n", arraySize);
    for (int i = 0; i < arraySize; i++)
    {
        scanf("%d", &array[i]);
    }
    // Create threads
    for (int i = 0; i < NUM_THREADS; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, calculateSum, &thread_ids[i]);
    }
    // Wait for threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    // Calculate the total sum
    int totalSum = 0;
    for (int i = 0; i < NUM_THREADS; i++)
    {
        totalSum += partialSum[i];
    }
    printf("Total sum: %d\n", totalSum);
    return 0;
}
